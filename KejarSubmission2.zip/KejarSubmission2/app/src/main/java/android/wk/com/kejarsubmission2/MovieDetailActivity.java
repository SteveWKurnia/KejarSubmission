package android.wk.com.kejarsubmission2;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.wk.com.kejarsubmission2.POJO.MovieModel;

import com.squareup.picasso.Picasso;

public class MovieDetailActivity extends AppCompatActivity {

    MovieModel movieModel;
    ImageView poster, back_button;
    TextView title, synopsis, rating, playtime, release_date;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_details);
        setData();

        poster = findViewById(R.id.poster_detail);
        title = findViewById(R.id.title_detail);
        synopsis = findViewById(R.id.synopsis_detail);
        rating = findViewById(R.id.rating_detail);
        playtime = findViewById(R.id.playtime_detail);
        release_date = findViewById(R.id.release_date_detail);
        back_button = findViewById(R.id.back_button);

        Picasso.get().load(movieModel.getPoster()).resize((int)getResources().getDimension(R.dimen.poster_width),(int) getResources().getDimension(R.dimen.poster_height)).into(poster);
        title.setText(movieModel.getTitle());
        synopsis.setText(movieModel.getSynopsis());
        rating.setText(movieModel.getRating()+"%");
        playtime.setText(movieModel.getPlaytime()+"min");
        release_date.setText(movieModel.getRelease_date());
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void setData(){
        if (getIntent().hasExtra("parcelledData")){
            movieModel = getIntent().getParcelableExtra("parcelledData");
        }
    }

}
