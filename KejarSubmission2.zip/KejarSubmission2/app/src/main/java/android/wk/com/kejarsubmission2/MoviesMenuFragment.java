package android.wk.com.kejarsubmission2;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.wk.com.kejarsubmission2.Adapter.MovieAdapter;
import android.wk.com.kejarsubmission2.POJO.MovieModel;

import java.util.ArrayList;

public class MoviesMenuFragment extends Fragment {

    private String[] movieTitle;
    private String[] moviePlaytime;
    private String[] movieReleaseDate;
    private String[] movieSynopsis;
    private TypedArray moviePoster;
    private String[] movieRating;

    private ArrayList<MovieModel> movieModels;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.movies_fragment, container, false);

        prepData();
        movieModels = addData();
        RecyclerView recyclerView = view.findViewById(R.id.movies_recycler);
        MovieAdapter movieAdapter = new MovieAdapter(movieModels,this.getContext());
        recyclerView.setAdapter(movieAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext(),LinearLayoutManager.VERTICAL,false));

        return view;
    }

    private ArrayList<MovieModel> addData(){
        ArrayList<MovieModel> movieModels = new ArrayList<>();

        for (int i=0;i<movieTitle.length;i++){
            movieModels.add(new MovieModel(movieTitle[i],moviePlaytime[i],movieRating[i],movieReleaseDate[i],movieSynopsis[i],moviePoster.getResourceId(i,-1)));
        }

        return movieModels;
    }

    private void prepData(){
        this.movieTitle = getResources().getStringArray(R.array.movies_title);
        this.moviePlaytime = getResources().getStringArray(R.array.movies_runtime);
        this.movieReleaseDate = getResources().getStringArray(R.array.movies_release_date);
        this.movieSynopsis = getResources().getStringArray(R.array.movies_synopsis);
        this.movieRating = getResources().getStringArray(R.array.movies_rating);
        this.moviePoster = getResources().obtainTypedArray(R.array.movies_poster);
    }

}
