package android.wk.com.kejarsubmission2.POJO;

import android.os.Parcel;
import android.os.Parcelable;

public class MovieModel implements Parcelable {
    private String title;
    private String playtime;
    private String rating;
    private String release_date;
    private String synopsis;
    private Integer poster;

    public MovieModel(String title, String playtime, String rating, String release_date, String synopsis, Integer poster) {
        this.title = title;
        this.playtime = playtime;
        this.rating = rating;
        this.release_date = release_date;
        this.synopsis = synopsis;
        this.poster = poster;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPlaytime() {
        return playtime;
    }

    public String getRating() {
        return rating;
    }
    public String getRelease_date() {
        return release_date;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public Integer getPoster() {
        return poster;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.playtime);
        dest.writeString(this.rating);
        dest.writeString(this.release_date);
        dest.writeString(this.synopsis);
        dest.writeValue(this.poster);
    }

    protected MovieModel(Parcel in) {
        this.title = in.readString();
        this.playtime = in.readString();
        this.rating = in.readString();
        this.release_date = in.readString();
        this.synopsis = in.readString();
        this.poster = (Integer) in.readValue(Integer.class.getClassLoader());
    }

    public static final Creator<MovieModel> CREATOR = new Creator<MovieModel>() {
        @Override
        public MovieModel createFromParcel(Parcel source) {
            return new MovieModel(source);
        }

        @Override
        public MovieModel[] newArray(int size) {
            return new MovieModel[size];
        }
    };
}
