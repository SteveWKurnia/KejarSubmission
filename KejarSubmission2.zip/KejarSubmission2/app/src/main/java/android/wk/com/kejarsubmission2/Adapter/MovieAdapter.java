package android.wk.com.kejarsubmission2.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.wk.com.kejarsubmission2.MovieDetailActivity;
import android.wk.com.kejarsubmission2.POJO.MovieModel;
import android.wk.com.kejarsubmission2.R;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.viewHolder> {

    Context context;
    ArrayList<MovieModel> movieModels;

    public MovieAdapter(ArrayList<MovieModel> movieModels, Context context) {
        this.movieModels = movieModels;
        this.context = context;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_content,viewGroup,false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final viewHolder viewHolder, final int i) {
        viewHolder.title.setText(movieModels.get(i).getTitle());
        viewHolder.poster.setImageResource(movieModels.get(i).getPoster());
        viewHolder.releaseDate.setText(movieModels.get(i).getRelease_date());
        viewHolder.synopsis.setText(movieModels.get(i).getSynopsis());
        viewHolder.playtime.setText(movieModels.get(i).getPlaytime()+"min");
        viewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),MovieDetailActivity.class);
                intent.putExtra("parcelledData",movieModels.get(i));
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movieModels.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder{

        TextView title;
        TextView playtime;
        TextView synopsis;
        TextView releaseDate;
        ImageView poster;
        CardView cardView;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title_recycler);
            playtime = itemView.findViewById(R.id.playtime_recycler);
            synopsis = itemView.findViewById(R.id.synopsis);
            releaseDate = itemView.findViewById(R.id.release_date_recycler);
            poster = itemView.findViewById(R.id.poster_recycler);
            cardView = itemView.findViewById(R.id.cardview);
        }
    }
}
