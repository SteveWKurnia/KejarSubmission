package android.wk.com.kejarsubmission2.ViewModels;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.res.Resources;
import android.support.v4.os.ConfigurationCompat;
import android.util.Log;
import android.wk.com.kejarsubmission2.Interfaces.RetrofitTVShowsAPI;
import android.wk.com.kejarsubmission2.POJO.TVShowsModelSuperclass;
import android.wk.com.kejarsubmission2.POJO.TVShowsModelAPI;

import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.wk.com.kejarsubmission2.MainActivity.setError;

public class TVShowsRetrofitViewModel extends ViewModel {

    private MutableLiveData<ArrayList<TVShowsModelAPI>> movieModelAPIMutableLiveData = new MutableLiveData<>();
    private Locale locale = ConfigurationCompat.getLocales(Resources.getSystem().getConfiguration()).get(0);

    public void setShows(){
        Log.d("retro","setting shows");
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.themoviedb.org/3/discover/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RetrofitTVShowsAPI retrofitTVShowsAPI = retrofit.create(RetrofitTVShowsAPI.class);

        Call<TVShowsModelSuperclass> call = retrofitTVShowsAPI.getShows("1b435eb50c1cd71e035609fa4da34ab4","en-US");
        if (locale.getLanguage().equals("en")){
            call = retrofitTVShowsAPI.getShows("1b435eb50c1cd71e035609fa4da34ab4","en-US");
        }else if(locale.getLanguage().equals("in")){
            call = retrofitTVShowsAPI.getShows("1b435eb50c1cd71e035609fa4da34ab4","id-ID");
        }

        call.enqueue(new Callback<TVShowsModelSuperclass>() {
            @Override
            public void onResponse(Call<TVShowsModelSuperclass> call, Response<TVShowsModelSuperclass> response) {
                if (!response.isSuccessful()){
                    Log.d("ErrorResponse",Integer.toString(response.code()));
                }
                TVShowsModelSuperclass TVShowsModelSuperclass = response.body();
                movieModelAPIMutableLiveData.postValue(TVShowsModelSuperclass.getResults());
            }

            @Override
            public void onFailure(Call<TVShowsModelSuperclass> call, Throwable t) {
                setError();
            }
        });
    }

    public LiveData<ArrayList<TVShowsModelAPI>> getShows(){
        return movieModelAPIMutableLiveData;
    }




}
