package android.wk.com.kejarsubmission2;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.wk.com.kejarsubmission2.POJO.MovieModelAPI;
import android.wk.com.kejarsubmission2.POJO.TVShowsModelAPI;

import com.squareup.picasso.Picasso;

import static android.wk.com.kejarsubmission2.Adapter.TVShowsAdapterAPI.POSTER_FILE;
import static android.wk.com.kejarsubmission2.Adapter.TVShowsAdapterAPI.POSTER_SIZE;

public class MovieDetailActivity extends AppCompatActivity {

    MovieModelAPI movieModelAPI;
    TVShowsModelAPI tvShowsModelAPI;
    ImageView poster, back_button;
    TextView title, synopsis, rating, release_date;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_details);
        setData();

        poster = findViewById(R.id.poster_detail);
        title = findViewById(R.id.title_detail);
        synopsis = findViewById(R.id.synopsis_detail);
        rating = findViewById(R.id.rating_detail);
        release_date = findViewById(R.id.release_date_detail);
        back_button = findViewById(R.id.back_button);

        if (movieModelAPI!=null){
            Picasso.get().load(POSTER_FILE + POSTER_SIZE + movieModelAPI.getPoster_path()).resize((int)getResources().getDimension(R.dimen.poster_width),(int) getResources().getDimension(R.dimen.poster_height)).into(poster);
            title.setText(movieModelAPI.getTitle());
            synopsis.setText(movieModelAPI.getOverview());
            Double rating_api = movieModelAPI.getVote_average();
            String rating_str = Double.toString(rating_api);
            rating.setText(rating_str);
            release_date.setText(movieModelAPI.getRelease_date());
        }else{
            Picasso.get().load(POSTER_FILE + POSTER_SIZE + tvShowsModelAPI.getPoster_path()).resize((int)getResources().getDimension(R.dimen.poster_width),(int) getResources().getDimension(R.dimen.poster_height)).into(poster);
            title.setText(tvShowsModelAPI.getName());
            synopsis.setText(tvShowsModelAPI.getOverview());
            Double rating_api = tvShowsModelAPI.getVote_average();
            String rating_str = Double.toString(rating_api);
            rating.setText(rating_str);
            release_date.setText(tvShowsModelAPI.getFirst_air_date());
        }
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void setData(){
        if (getIntent().hasExtra("parcelledAPIData")){
            movieModelAPI = getIntent().getParcelableExtra("parcelledAPIData");
        }else{
            tvShowsModelAPI = getIntent().getParcelableExtra("parcelledTVShows");
        }
    }

}
