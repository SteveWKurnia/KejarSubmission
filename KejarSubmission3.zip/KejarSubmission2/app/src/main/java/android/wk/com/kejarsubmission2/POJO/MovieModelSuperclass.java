package android.wk.com.kejarsubmission2.POJO;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class MovieModelSuperclass implements Parcelable {
    private int page;
    private int total_results;
    private int total_pages;
    private ArrayList<MovieModelAPI> results;

    public ArrayList<MovieModelAPI> getResults() {
        return results;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.page);
        dest.writeInt(this.total_results);
        dest.writeInt(this.total_pages);
        dest.writeTypedList(this.results);
    }

    public MovieModelSuperclass() {
    }

    protected MovieModelSuperclass(Parcel in) {
        this.page = in.readInt();
        this.total_results = in.readInt();
        this.total_pages = in.readInt();
        this.results = in.createTypedArrayList(MovieModelAPI.CREATOR);
    }

    public static final Parcelable.Creator<MovieModelSuperclass> CREATOR = new Parcelable.Creator<MovieModelSuperclass>() {
        @Override
        public MovieModelSuperclass createFromParcel(Parcel source) {
            return new MovieModelSuperclass(source);
        }

        @Override
        public MovieModelSuperclass[] newArray(int size) {
            return new MovieModelSuperclass[size];
        }
    };
}
