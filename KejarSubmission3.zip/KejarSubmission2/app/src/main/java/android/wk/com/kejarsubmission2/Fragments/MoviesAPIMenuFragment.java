package android.wk.com.kejarsubmission2.Fragments;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.wk.com.kejarsubmission2.Adapter.MovieAdapterAPI;
import android.wk.com.kejarsubmission2.POJO.MovieModelAPI;
import android.wk.com.kejarsubmission2.R;
import android.wk.com.kejarsubmission2.ViewModels.MoviesRetrofitViewModel;

import java.util.ArrayList;


public class MoviesAPIMenuFragment extends Fragment {

    private MovieAdapterAPI movieAdapterAPI;
    private ProgressBar progressBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater
                .inflate(R.layout.movies_fragment, container,false);

        progressBar = view.findViewById(R.id.progress_bar);

        MoviesRetrofitViewModel moviesRetrofitViewModel;
        moviesRetrofitViewModel = ViewModelProviders.of(this).get(MoviesRetrofitViewModel.class);
        moviesRetrofitViewModel.getMovies().observe(this, getMovies);

        RecyclerView recyclerView = view.findViewById(R.id.movies_recycler);

        movieAdapterAPI = new MovieAdapterAPI();
        movieAdapterAPI.notifyDataSetChanged();

        recyclerView.setAdapter(movieAdapterAPI);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));

        moviesRetrofitViewModel.setMovie();

        return view;
    }

    private Observer<ArrayList<MovieModelAPI>> getMovies = new Observer<ArrayList<MovieModelAPI>>() {
        @Override
        public void onChanged(@Nullable ArrayList<MovieModelAPI> movieModelAPIS) {
            if (movieModelAPIS!=null){
                movieAdapterAPI.setData(movieModelAPIS);
                progressBar.setVisibility(View.GONE);
            }
        }
    };

}
