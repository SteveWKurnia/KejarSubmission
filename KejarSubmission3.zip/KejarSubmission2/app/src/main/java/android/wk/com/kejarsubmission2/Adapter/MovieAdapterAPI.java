package android.wk.com.kejarsubmission2.Adapter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.wk.com.kejarsubmission2.MovieDetailActivity;
import android.wk.com.kejarsubmission2.POJO.MovieModelAPI;
import android.wk.com.kejarsubmission2.R;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MovieAdapterAPI extends RecyclerView.Adapter<MovieAdapterAPI.MyViewHolder> {

    private ArrayList<MovieModelAPI> movieModelAPIArrayList = new ArrayList<>();
    private static final String POSTER_SIZE = "original";
    private static final String POSTER_FILE = "https://image.tmdb.org/t/p/";

    public void setData(ArrayList<MovieModelAPI> items) {
        movieModelAPIArrayList.clear();
        movieModelAPIArrayList.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_api_recycler,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {
        myViewHolder.bind(movieModelAPIArrayList.get(i));
        myViewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),MovieDetailActivity.class);
                intent.putExtra("parcelledAPIData",movieModelAPIArrayList.get(i));
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return movieModelAPIArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView title;
        TextView rate;
        TextView description;
        TextView release_date;
        ImageView poster;
        CardView cardView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardview_out);
            title = itemView.findViewById(R.id.title_recycler_api);
            description = itemView.findViewById(R.id.synopsis_api);
            release_date = itemView.findViewById(R.id.release_date_recycler_api);
            poster = itemView.findViewById(R.id.poster_recycler_api);
            rate = itemView.findViewById(R.id.rating_recycler_api);
        }

        void bind(MovieModelAPI movieModelAPI){

            title.setText(movieModelAPI.getTitle());
            title.setSelected(true);
            description.setText(movieModelAPI.getOverview());
            release_date.setText(movieModelAPI.getRelease_date());

            String rating = Double.toString(movieModelAPI.getVote_average());
            rate.setText(rating);

            Picasso.get().load(POSTER_FILE + POSTER_SIZE + movieModelAPI.getPoster_path()).into(poster);
        }

    }

}
