package android.wk.com.kejarsubmission2;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;
import android.wk.com.kejarsubmission2.Fragments.MoviesAPIMenuFragment;
import android.wk.com.kejarsubmission2.Fragments.TVShowsAPIMenuFragment;

import static android.wk.com.kejarsubmission2.Utilities.MyApplicationContext.getAppContext;

public class MainActivity extends AppCompatActivity{

    Fragment fragment;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.movies_api_nav:
                    fragment = new MoviesAPIMenuFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.tv_retrofit_nav:
                    fragment = new TVShowsAPIMenuFragment();
                    loadFragment(fragment);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setElevation(0);
        setSupportActionBar(toolbar);

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        if (savedInstanceState == null){
            fragment = new MoviesAPIMenuFragment();
            loadFragment(fragment);
        }else{
            fragment = getSupportFragmentManager().getFragment(savedInstanceState,"fragment");
            loadFragment(fragment);
        }
    }

    void loadFragment(Fragment fragment){
        if (fragment != null){
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frame_layout,fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.toolbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Integer id = item.getItemId();
        if(id == R.id.language_setting){
            Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(intent);
        }

        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        getSupportFragmentManager().putFragment(outState,"fragment",fragment);
        super.onSaveInstanceState(outState);
    }

    public static void setError(){
        Toast.makeText( getAppContext(),"Error loading...", Toast.LENGTH_SHORT).show();
    }
}
