package android.wk.com.kejarsubmission2.Adapter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.wk.com.kejarsubmission2.MovieDetailActivity;
import android.wk.com.kejarsubmission2.POJO.TVShowsModelAPI;
import android.wk.com.kejarsubmission2.R;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TVShowsAdapterAPI extends RecyclerView.Adapter<TVShowsAdapterAPI.ViewHolder>{

    private ArrayList<TVShowsModelAPI> tvShowsModelAPI = new ArrayList<>();
    public static final String POSTER_SIZE = "original";
    public static final String POSTER_FILE = "https://image.tmdb.org/t/p/";

    public void setData(ArrayList<TVShowsModelAPI> items) {
        tvShowsModelAPI.clear();
        tvShowsModelAPI.addAll(items);
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_api_recycler,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        viewHolder.bind(tvShowsModelAPI.get(i));
        viewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),MovieDetailActivity.class);
                intent.putExtra("parcelledTVShows",tvShowsModelAPI.get(i));
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return tvShowsModelAPI.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView title;
        TextView rate;
        TextView description;
        TextView release_date;
        ImageView poster;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardview_out);
            title = itemView.findViewById(R.id.title_recycler_api);
            description = itemView.findViewById(R.id.synopsis_api);
            release_date = itemView.findViewById(R.id.release_date_recycler_api);
            poster = itemView.findViewById(R.id.poster_recycler_api);
            rate = itemView.findViewById(R.id.rating_recycler_api);
        }

        void bind(TVShowsModelAPI tvShowsModelAPI){

            title.setText(tvShowsModelAPI.getName());
            title.setSelected(true);
            description.setText(tvShowsModelAPI.getOverview());
            release_date.setText(tvShowsModelAPI.getFirst_air_date());

            String rating = Double.toString(tvShowsModelAPI.getVote_average());
            rate.setText(rating);

            Picasso.get().load(POSTER_FILE + POSTER_SIZE + tvShowsModelAPI.getPoster_path()).into(poster);
        }

    }

}
