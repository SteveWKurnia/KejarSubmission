package android.wk.com.kejarsubmission2.POJO;

import android.os.Parcel;
import android.os.Parcelable;

public class TVShowsModelAPI implements Parcelable {
    private String name;
    private String first_air_date;
    private double vote_average;
    private String poster_path;
    private String overview;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFirst_air_date() {
        return first_air_date;
    }


    public double getVote_average() {
        return vote_average;
    }


    public String getPoster_path() {
        return poster_path;
    }

    public String getOverview() {
        return overview;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.first_air_date);
        dest.writeDouble(this.vote_average);
        dest.writeString(this.poster_path);
        dest.writeString(this.overview);
    }

    public TVShowsModelAPI() {
    }

    protected TVShowsModelAPI(Parcel in) {
        this.name = in.readString();
        this.first_air_date = in.readString();
        this.vote_average = in.readDouble();
        this.poster_path = in.readString();
        this.overview = in.readString();
    }

    public static final Parcelable.Creator<TVShowsModelAPI> CREATOR = new Parcelable.Creator<TVShowsModelAPI>() {
        @Override
        public TVShowsModelAPI createFromParcel(Parcel source) {
            return new TVShowsModelAPI(source);
        }

        @Override
        public TVShowsModelAPI[] newArray(int size) {
            return new TVShowsModelAPI[size];
        }
    };
}
