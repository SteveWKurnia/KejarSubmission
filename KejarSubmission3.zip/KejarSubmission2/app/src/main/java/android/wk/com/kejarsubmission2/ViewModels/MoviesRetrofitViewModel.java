package android.wk.com.kejarsubmission2.ViewModels;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.res.Resources;
import android.support.v4.os.ConfigurationCompat;
import android.util.Log;
import android.wk.com.kejarsubmission2.Interfaces.RetrofitMoviesAPI;
import android.wk.com.kejarsubmission2.POJO.MovieModelAPI;
import android.wk.com.kejarsubmission2.POJO.MovieModelSuperclass;

import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.wk.com.kejarsubmission2.MainActivity.setError;

public class MoviesRetrofitViewModel extends ViewModel {
    private static final String API_KEY = "1b435eb50c1cd71e035609fa4da34ab4";
    private static final String LOCALE_ID = "id-ID";
    private static final String LOCALE_US = "en-US";
    private static final String URL = "https://api.themoviedb.org/3/discover/";

    private MutableLiveData<ArrayList<MovieModelAPI>> listMovies = new MutableLiveData<>();
    Locale locale = ConfigurationCompat.getLocales(Resources.getSystem().getConfiguration()).get(0);


    public void setMovie(){
        Log.d("TAGGING",locale.getLanguage());
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RetrofitMoviesAPI retrofitMoviesAPI = retrofit.create(RetrofitMoviesAPI.class);


        Call<MovieModelSuperclass> call = retrofitMoviesAPI.getMovies(API_KEY,LOCALE_US);
        if (locale.getLanguage().equals("en")){
            call = retrofitMoviesAPI.getMovies(API_KEY,LOCALE_US);
        }else if (locale.getLanguage().equals("in")){
            call = retrofitMoviesAPI.getMovies(API_KEY,LOCALE_ID);
        }
        call.enqueue(new Callback<MovieModelSuperclass>() {
            @Override
            public void onResponse(Call<MovieModelSuperclass> call, Response<MovieModelSuperclass> response) {
                if (!response.isSuccessful()){
                    Log.d("retro", Integer.toString(response.code()));
                }
                MovieModelSuperclass movieModelSuperclass = response.body();
                listMovies.postValue(movieModelSuperclass.getResults());
            }

            @Override
            public void onFailure(Call<MovieModelSuperclass> call, Throwable t) {
                setError();
            }
        });
    }

    public LiveData<ArrayList<MovieModelAPI>> getMovies(){
        return listMovies;
    }

}
