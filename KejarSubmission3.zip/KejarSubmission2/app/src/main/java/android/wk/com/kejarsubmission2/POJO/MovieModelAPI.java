package android.wk.com.kejarsubmission2.POJO;

import android.os.Parcel;
import android.os.Parcelable;

public class MovieModelAPI implements Parcelable {
    private String title;
    private double vote_average;
    private String poster_path;
    private String overview;
    private String release_date;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getVote_average() {
        return vote_average;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public String getOverview() {
        return overview;
    }

    public String getRelease_date() {
        return release_date;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeDouble(this.vote_average);
        dest.writeString(this.poster_path);
        dest.writeString(this.overview);
        dest.writeString(this.release_date);
    }

    public MovieModelAPI(){

    }

    protected MovieModelAPI(Parcel in) {
        this.title = in.readString();
        this.vote_average = in.readDouble();
        this.poster_path = in.readString();
        this.overview = in.readString();
        this.release_date = in.readString();
    }

    public static final Parcelable.Creator<MovieModelAPI> CREATOR = new Parcelable.Creator<MovieModelAPI>() {
        @Override
        public MovieModelAPI createFromParcel(Parcel source) {
            return new MovieModelAPI(source);
        }

        @Override
        public MovieModelAPI[] newArray(int size) {
            return new MovieModelAPI[size];
        }
    };
}
