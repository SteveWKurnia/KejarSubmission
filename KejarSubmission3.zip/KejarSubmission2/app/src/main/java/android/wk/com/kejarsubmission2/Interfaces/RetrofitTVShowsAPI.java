package android.wk.com.kejarsubmission2.Interfaces;

import android.wk.com.kejarsubmission2.POJO.TVShowsModelSuperclass;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrofitTVShowsAPI {

    @GET("tv")
    Call<TVShowsModelSuperclass> getShows(@Query("api_key") String API_KEY,
                                          @Query("language") String LOCALE);
}
