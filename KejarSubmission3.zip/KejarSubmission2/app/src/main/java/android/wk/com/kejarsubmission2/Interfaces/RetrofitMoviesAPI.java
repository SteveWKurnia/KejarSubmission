package android.wk.com.kejarsubmission2.Interfaces;

import android.wk.com.kejarsubmission2.POJO.MovieModelSuperclass;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrofitMoviesAPI {

    @GET("movie")
    Call<MovieModelSuperclass>getMovies(@Query("api_key") String API_KEY,
                                                   @Query("language") String LOCALE);

}
