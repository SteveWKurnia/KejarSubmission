package android.wk.com.kejarsubmission2.Fragments;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.wk.com.kejarsubmission2.Adapter.TVShowsAdapterAPI;
import android.wk.com.kejarsubmission2.POJO.TVShowsModelAPI;
import android.wk.com.kejarsubmission2.R;
import android.wk.com.kejarsubmission2.ViewModels.TVShowsRetrofitViewModel;

import java.util.ArrayList;

public class TVShowsAPIMenuFragment extends Fragment {

    private TVShowsAdapterAPI tvShowsAdapterAPI;
    private ProgressBar progressBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater
                .inflate(R.layout.tvshows_fragment,container,false);
        progressBar = view.findViewById(R.id.tvshows_progressbar);

        TVShowsRetrofitViewModel TVShowsRetrofitViewModel = ViewModelProviders.of(this).get(TVShowsRetrofitViewModel.class);
        TVShowsRetrofitViewModel.getShows().observe(this, getShows);

        tvShowsAdapterAPI = new TVShowsAdapterAPI();
        tvShowsAdapterAPI.notifyDataSetChanged();

        RecyclerView recyclerView = view.findViewById(R.id.tvshows_recycler);
        recyclerView.setAdapter(tvShowsAdapterAPI);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));

        TVShowsRetrofitViewModel.setShows();

        return view;
    }

    private Observer<ArrayList<TVShowsModelAPI>> getShows = new Observer<ArrayList<TVShowsModelAPI>>() {
        @Override
        public void onChanged(@Nullable ArrayList<TVShowsModelAPI> tvShowsModelAPIS) {
            if (tvShowsModelAPIS!=null){
                tvShowsAdapterAPI.setData(tvShowsModelAPIS);
                progressBar.setVisibility(View.GONE);
            }
        }
    };

}
